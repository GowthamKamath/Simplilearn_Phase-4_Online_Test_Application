let questions = 
[
    {
        numb : 1,
        question : "What Does HTML Stand's For?",
        answer : "Hiper Text Markup Language",
        option:
        [
            "Hiper Text Markup Language",
            "Hiper Text Processor",
            "Hiper Text Processor",
            "Hiper Text Processor"
        ]
    },
    {
        numb : 2,
        question : "What Does CSS Stand's For?",
        answer : "Cascade Style Sheet",
        option:
        [
            "Cascade Style Sheet",
            "Cursor Style Sheet",
            "Style Sheet Cascade",
            "Hiper Text Processor"
        ]
    },
    {
        numb : 3,
        question : "What Does SQL Stand's For?",
        answer : "Structured Query Language",
        option:
        [
            "Standard Query Language",
            "Cursor Style Sheet",
            "Style Sheet Cascade",
            "Structured Query Language"
        ]
    },
    {
        numb : 4,
        question : "What Does UPSC Stand's For?",
        answer : "Union Public Service Commision",
        option:
        [
            "Central Union Public Service Commision",
            "Uttar Pradesh Public Commision",
            "Style Sheet Cascade",
            "Union Public Service Commision"
        ]
    },
    {
        numb : 5,
        question : "What Does MPSC Stand's For?",
        answer : "Maharashtra Public Service Commision",
        option:
        [
            "Madhya Pradesh Service Commision",
            "Madrass Public Service Commision",
            "Maharashtra Public Service Commision",
            "Hiper Text Processor"
        ]
    }
        

]